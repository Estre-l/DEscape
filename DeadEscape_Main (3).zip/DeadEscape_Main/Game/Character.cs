﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Character : GameObject, IDamagable 
    {
        private Life lifeController;
        private DateTime damageTime;
        private float timeBetweenDamage = 0.3f;
        private float _movementSpeed;

        #region PUBLIC_METODS
        public Character(string texturePath, Vector2 position, Vector2 scale, float angle, float movementSpeed) : base(position, scale, angle, movementSpeed)
        {
            lifeController = new Life(100);
            currentAnimation = idleAnimation;
            _movementSpeed = movementSpeed;
        }

        public override void GetDamage(int damage)
        {
            lifeController.GetDamage(damage);
        }
        public override void Destroy()
        {
            if (lifeController.IsAlive == false)
            {
                GameManager.Instance.ChangeGameState(GameState.GameOverScreen);
            }
        }
        protected override void CreateAnimations()
        {
            List<Texture> idleTextures = new List<Texture>();
            for (int i = 0; i < 4; i++)
            {
                Texture frame = Engine.GetTexture($"Textures/Ship/{i}.png");
                idleTextures.Add(frame);
            }
            idleAnimation = new Animation("Idle", idleTextures, 0.1f, true);
        }

        public void Initialize() { }

        public override void Update()
        {
            InputReading();
            CheckCollision();

            currentAnimation.Update();

            if (_transform.Position.Y >= 800)
                _transform.SetPositon(new Vector2(_transform.Position.X, 51));
            if (_transform.Position.Y <= 50)
                _transform.SetPositon(new Vector2(_transform.Position.X, 800));
            if (_transform.Position.X <= 0)
                _transform.SetPositon(new Vector2(0, _transform.Position.Y));
        }

        public void CheckCollision()
        {
            for (int i = 0; i < GameManager.Instance.LevelController.gameObjects.Count; i++)
            {
                GameObject go = GameManager.Instance.LevelController.gameObjects[i];
                if (go is IDamagable)
                {
                    
                    float distanceX = Math.Abs(go.Transform.Position.X - _transform.Position.X);
                    float distanceY = Math.Abs(go.Transform.Position.Y - _transform.Position.Y);

                    float sumHalfWidths = go.Renderer.Texture.Width / 9 + go.Transform.Scale.X / 9;
                    float sumHalfHeights = go.Renderer.Texture.Height / 6 + go.Transform.Scale.Y / 6;

                    if (distanceX <= sumHalfWidths && distanceY <= sumHalfHeights)
                    {
                        DateTime currentTime = DateTime.Now;
                        if ((currentTime - damageTime).TotalSeconds >= timeBetweenDamage)
                        {
                            GetDamage(10);
                            Engine.Debug("Vida: " + lifeController.currentLife);
                            damageTime = currentTime;
                        }
                         go.Destroy();
                         Destroy();
                    }
                }
            }
        }
        #endregion

        #region PRIVATE_METHODS

        private void InputReading()
        {
            if (Engine.GetKey(Keys.W)) MoveUp();
            if (Engine.GetKey(Keys.S)) MoveDown();
            if (Engine.GetKey(Keys.A)) MoveLeft();
            if (Engine.GetKey(Keys.D)) MoveRight();
        }
        private void MoveUp() => _transform.Translate(new Vector2(0, -1), _movementSpeed);
        private void MoveDown() => _transform.Translate(new Vector2(0, 1), _movementSpeed);
        private void MoveLeft() => _transform.Translate(new Vector2(-1, 0), _movementSpeed);
        private void MoveRight() => _transform.Translate(new Vector2(1, 0), _movementSpeed);

        #endregion
    }
}
