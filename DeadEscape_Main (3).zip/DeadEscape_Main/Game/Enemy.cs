﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Enemy : GameObject, IDamagable
    {
        /* Character Properties */
        private Character _player;
        private float _movementSpeed;
        
        #region PUBLIC_METODS

        public Enemy(Vector2 position, Vector2 scale, float angle, float movementSpeed):base(position,scale,angle,movementSpeed)
        {
            _player = GameManager.Instance.LevelController.Player;
            _transform = new Transform(position, scale, angle);
            currentAnimation = idleAnimation;
            _renderer = new Renderer(idleAnimation, scale);
            _movementSpeed = movementSpeed;
        }

        protected override void CreateAnimations()
        {
            List<Texture> idleTextures = new List<Texture>();
            for (int i = 0; i < 4; i++)
            {
                Texture frame = Engine.GetTexture("Textures/turret.png");
                idleTextures.Add(frame);
            }
            idleAnimation = new Animation("Idle", idleTextures, 0.1f, true);
        }
        public void Initialize() { }

        public override void Update()
        {
            CheckCollisionZombie();

            _transform.Translate(new Vector2(0.1f, 0), -_movementSpeed);
            if (_transform.Position.X >= 1280 + _renderer.Texture.Width)
                _transform.SetPositon(new Vector2(-_renderer.Texture.Width, _transform.Position.Y));

            currentAnimation.Update();
        }
        public void CheckCollisionZombie()
        {
            for (int i = 0; i < GameManager.Instance.LevelController.gameObjects.Count; i++)
            {
                GameObject p = GameManager.Instance.LevelController.Player;
                if (p is IDamagable)
                {
                    float distanceX = Math.Abs(p.Transform.Position.X - _transform.Position.X);
                    float distanceY = Math.Abs(p.Transform.Position.Y - _transform.Position.Y);

                    float sumHalfWidths = p.Renderer.Texture.Width / 10 + p.Transform.Scale.X / 10;
                    float sumHalfHeights = p.Renderer.Texture.Height / 10 + p.Transform.Scale.Y / 10;
                }
            }
        }
        #endregion
    }
}
