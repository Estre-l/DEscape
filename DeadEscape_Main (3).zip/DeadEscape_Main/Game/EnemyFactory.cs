﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public enum EnemyType
    {
        littleZ=0,
        MidZ=1,
        BigZ=2,

    }
    public static class EnemyFactory 
    {
        public static Enemy CreateEnemy(EnemyType enemyType, Vector2 position)
        {
            switch (enemyType)
            {
                case EnemyType.littleZ:
                    return new Enemy (position, new Vector2(.25f, .25f), 0, -150);
                case EnemyType.MidZ:
                    return new Enemy (position, new Vector2(.25f, .25f), 0, 150);
                case EnemyType.BigZ:
                    return new Enemy(position, new Vector2(.25f, .25f), 0, -800);
            }
            return null;
        }
    }
}
