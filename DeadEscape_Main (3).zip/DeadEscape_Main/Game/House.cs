﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class House
    {
        /* Character Properties */
        private Character _player;
        private Renderer _renderer;
        private Transform _transform;
        private Animation idleAnimation;
        private Animation currentAnimation;

        public House(string texturePath,Vector2 position, Vector2 scale, float angle)
        {
            _player = GameManager.Instance.LevelController.Player;
            _transform = new Transform(position, scale, angle);

            CreateAnimations();
            currentAnimation = idleAnimation;

            _renderer = new Renderer(idleAnimation, scale);
        }
        
        public void Initialize() { }

        public void Update()
        {
            currentAnimation.Update();
            CheckCollision();
        }
        protected void CreateAnimations()
        {
            List<Texture> idleTextures = new List<Texture>();
            for (int i = 0; i < 4; i++)
            {
                Texture frame = Engine.GetTexture("Textures/House/casa.png");
                idleTextures.Add(frame);
            }
            idleAnimation = new Animation("casa", idleTextures, 0.1f, true);
        }
        public virtual void Render()
        {
            _renderer.Render(_transform);
        }
        public void CheckCollision()
        {

            for (int i=0; i < GameManager.Instance.LevelController.gameObjects.Count; i++) 
            {
                GameObject p = GameManager.Instance.LevelController.Player;
                if(p is IDamagable)
                {
                    float distanceX = Math.Abs(p.Transform.Position.X - _transform.Position.X);
                    float distanceY = Math.Abs(p.Transform.Position.Y - _transform.Position.Y);

                    float sumHalfWidths = p.Renderer.Texture.Width / 0.3f + p.Transform.Scale.X / 0.3f;
                    float sumHalfHeights = p.Renderer.Texture.Height / 0.3f + p.Transform.Scale.Y / 0.3f;

                    if (distanceX <= sumHalfWidths && distanceY <= sumHalfHeights) 
                    {
                        GameManager.Instance.ChangeGameState(GameState.WinScreen);
                    }
                }
            }
        }
    }
}
