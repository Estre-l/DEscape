﻿using System;
using System.Collections.Generic;

namespace Game
{
    public class LevelController
    {
        private  Time _time;
        public  List<GameObject> gameObjects { get; set; } = new List<GameObject>();

        private  Character _player;
        public House _House;
        public Objeto _objeto;
        public  Character Player => _player;
        public  Random _random = new Random();
        public SingleScreen Level = new SingleScreen("Textures/Screens/Level.png");

        public void Initialization()
        {
            _time.Initialize();

            _player = new Character("Textures/ship.png", new Vector2(1450, 700), new Vector2(-2, 2), 0, 100);

            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.littleZ, new Vector2(120, 150))); //X,Y
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.littleZ, new Vector2(220, 220)));
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.littleZ, new Vector2(300, 340)));
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.littleZ, new Vector2(80, 480)));
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.littleZ, new Vector2(150, 510)));
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.littleZ, new Vector2(190, 690)));
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.BigZ, new Vector2(50, 400)));
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.BigZ, new Vector2(10, 200)));
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.BigZ, new Vector2(70, 300)));
            gameObjects.Add(EnemyFactory.CreateEnemy(EnemyType.BigZ, new Vector2(100, 500)));

            _House = new House("Textures/Bullet/casa.png",new Vector2(30,30),new Vector2(0.3f,0.3f),0);
            _objeto = new Objeto("Textures/Objeto/life.png", new Vector2(1000, 500), new Vector2(0.2f, 0.2f), 0);
        }
        public  void Update()
        {
            _time.Update();
            _player.Update();
            _House.Update();
            _objeto.Update();

            for(int i = 0; i < gameObjects.Count; i++)
            {
                gameObjects[i].Update();
            }
            
        }
        public void Render()
        {
            Engine.Clear();
            //Engine.Draw("Textures/Screens/Level.png");
            Level.Render();
            _House.Render();
            _player.Render();
            _objeto.Render();

            for (int i = 0; i < gameObjects.Count; i++)
            {
                gameObjects[i].Render();
            }
            Engine.Show();
        }
    }
}