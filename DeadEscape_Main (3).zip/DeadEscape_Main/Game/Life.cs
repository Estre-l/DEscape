﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Life
    {
        public delegate void GetDamageDelegate();
        public event GetDamageDelegate onGetDamage;
        private int _maxHealth;
        public int currentLife;
        public bool IsAlive =>currentLife > 0;

        public int CurrentLife
        {
            get => currentLife;
            set
            {
                currentLife = value;
                if (currentLife <= 0)
                {
                    GameManager.Instance.ChangeGameState(GameState.GameOverScreen);
                }
            }
        }
        public Life(int maxHealth)
        {
            _maxHealth = maxHealth;
            currentLife = _maxHealth;
        }

        public void GetDamage(int damage)
        {
            currentLife = currentLife - damage;
        }
    }
}
