﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class NotDynamicObjetoPool
    {
        public List<Objeto> ObjetoInUse = new List<Objeto>();
        public List<Objeto> ObjetoGen = new List<Objeto>();

        public NotDynamicObjetoPool(int capacity)
        {
            for (int i = 0; i < capacity; i++)
            {
                Objeto objeto = new Objeto("Textures/Objeto/life.png",new Vector2(0, 0), new Vector2(1f, 1f), 0);
                objeto.Desactiva += RecycleObjeto;
                ObjetoGen.Add(objeto);
            }
        }
        public Objeto GetObjeto()
        {
            Objeto objetoToReturn = null;
            if (ObjetoGen.Count > 0)
            {
                objetoToReturn = ObjetoGen[0];
                ObjetoGen.RemoveAt(0);
                ObjetoInUse.Add(objetoToReturn);
            }
            Engine.Debug("Obtenido: " + ObjetoInUse.Count());
            Engine.Debug("Spawneo: " + ObjetoGen.Count());
            return objetoToReturn;
        }
        private void RecycleObjeto(Objeto objeto)
        {
            if (ObjetoInUse.Contains(objeto))
            {
                ObjetoInUse.Remove(objeto);
                ObjetoGen.Add(objeto);
            }
        }
    }
}
