﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class Objeto : Iobject
    {
        private Character _player;
        private Renderer _renderer;
        private Transform _transform;
        private Animation idleAnimation;
        private Animation currentAnimation;
        public Random _random = new Random();

        private int objeto=0;

        public event Action<Objeto> Desactiva;
        public Objeto(string texturePath,Vector2 position, Vector2 scale, float angle)
        {
            _player = GameManager.Instance.LevelController.Player;
            //_player = LevelController.Player;
            _transform = new Transform(position, scale, angle);

            CreateAnimations();
            currentAnimation = idleAnimation;

            _renderer = new Renderer(idleAnimation, scale);
        }
        
        public void Initialize() { }

        public void Update()
        {
            currentAnimation.Update();
            CheckCollision();
        }
        protected void CreateAnimations()
        {
            List<Texture> idleTextures = new List<Texture>();
            for (int i = 0; i < 4; i++)
            {
                Texture frame = Engine.GetTexture("Textures/Objeto/life.png");
                idleTextures.Add(frame);
            }
            idleAnimation = new Animation("objeto", idleTextures, 0.1f, true);
        }
        public virtual void Render()
        {
            _renderer.Render(_transform);
        }

        public void GetObject(int obj)
        {
            objeto = objeto + obj;
            Engine.Debug("Puntos:" + obj);
        }

        public void CheckCollision()
        {

            for (int i=0; i < GameManager.Instance.LevelController.gameObjects.Count; i++) 
            {
                GameObject p = GameManager.Instance.LevelController.Player;
                if(p is IDamagable)
                {
                    float distanceX = Math.Abs(p.Transform.Position.X - _transform.Position.X);
                    float distanceY = Math.Abs(p.Transform.Position.Y - _transform.Position.Y);

                    float sumHalfWidths = p.Renderer.Texture.Width / 1f+ p.Transform.Scale.X / 1f;
                    float sumHalfHeights = p.Renderer.Texture.Height / 1f + p.Transform.Scale.Y / 1f;

                    if (distanceX <= sumHalfWidths && distanceY <= sumHalfHeights) 
                    {
                        GetObject(1);
                        _transform.SetPositon(new Vector2(_random.Next(30, 1450),_random.Next(10,850)));
                        Engine.Debug("Objetos: " + objeto);
                    }
                }
            }
        }
    }
}
