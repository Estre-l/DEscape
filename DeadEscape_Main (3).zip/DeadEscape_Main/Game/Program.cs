﻿using System;
using System.Collections.Generic;

namespace Game
{
    public class Program
    {

        static void Main(string[] args)
        {
            Engine.Initialize("Game", 1520, 855);

            GameManager.Instance.Initilization();

            while (true)
            {
                GameManager.Instance.Update(); //Llamo al update del manager.
                GameManager.Instance.Render(); //Llamo al manager.
            }
        }
    }
}