﻿using Game;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Media;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void GetDamageUnitTest()
        {
            int damage = 10;
            LifeController life = new LifeController(50);
            var expectedLife = life.CurrentLife - damage;
            life.GetDamage(damage);
            var actualLife = life.CurrentLife;
            Assert.AreEqual(expectedLife, actualLife);
        }
    }
}
